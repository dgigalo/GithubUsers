package ru.githubusers.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import ru.githubusers.model.UserRepo

@Entity(tableName = "users_table")
data class UserData (
    @PrimaryKey
    val userLogin:String,
    //val userName:String,
    @TypeConverters(RepoDataConverter::class)
    val data:ArrayList<UserRepo>
)